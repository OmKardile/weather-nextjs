'use client';

import {
  Cloud,
  Droplets,
  Eye,
  Gauge,
  Sun,
  Umbrella,
  Wind,
} from 'lucide-react';
import { daylightLength, sunProgress } from '@/lib/time';
import {
  compassPoint,
  formatHour,
  formatPrecip,
  formatPressure,
  formatTemp,
  formatVisibility,
  formatWind,
  visibilityLabel,
} from '@/lib/units';
import { ExpandableCard } from '@/components/weather/ExpandableCard';
import { MarineCard } from '@/components/weather/MarineCard';
import type { City, HourlyPoint, Units, WeatherBundle } from '@/types/weather';

interface MetricGridProps {
  data: WeatherBundle;
  units: Units;
  /** Active city — powers the marine card fetch. */
  city: City;
}

function dewPoint(celsius: number, humidity: number): number {
  const a = 17.27;
  const b = 237.7;
  const alpha = Math.log(Math.max(humidity, 1) / 100) + (a * celsius) / (b + celsius);
  return (b * alpha) / (a - alpha);
}

/** Non-expandable card chrome (used by Sun path only). */
function Card({
  icon,
  label,
  children,
  className,
}: {
  icon: React.ReactNode;
  label: string;
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <div className={`glass rounded-[var(--radius-card)] p-4 ${className ?? ''}`}>
      <p className="flex items-center gap-1.5 card-label">
        <span aria-hidden="true">{icon}</span>
        {label}
      </p>
      {children}
    </div>
  );
}

function WindCompass({ data, units }: { data: WeatherBundle; units: Units }) {
  const { windSpeed, windGust, windDirection } = data.current;
  const to = (windDirection + 180) % 360; // arrow points downwind

  return (
    <ExpandableCard
      label="Wind"
      group="wind"
      bundle={data}
      units={units}
      icon={<Wind className="h-3.5 w-3.5" />}
    >
      <div className="mt-2 flex items-center gap-3">
        <svg viewBox="0 0 72 72" className="h-16 w-16 shrink-0" role="img" aria-label={`Wind from ${compassPoint(windDirection)}`}>
          <circle cx="36" cy="36" r="30" fill="none" style={{ stroke: "var(--surface-border)" }} strokeWidth="2" />
          {(['N', 'E', 'S', 'W'] as const).map((point, i) => {
            const angle = (i * 90 - 90) * (Math.PI / 180);
            const x = 36 + Math.cos(angle) * 24;
            const y = 36 + Math.sin(angle) * 24;
            return (
              <text
                key={point}
                x={x}
                y={y + 3.2}
                textAnchor="middle"
                fontSize="9"
                style={{ fill: "var(--surface-muted)" }}
                className="tnum"
              >
                {point}
              </text>
            );
          })}
          <g transform={`rotate(${to} 36 36)`} style={{ transition: 'transform 600ms var(--ease-out-expo)' }}>
            <path d="M36 14 L41 40 L36 35 L31 40 Z" fill="#45D1B3" />
          </g>
          <circle cx="36" cy="36" r="3" style={{ fill: "var(--surface-strong)" }} stroke="#45D1B3" strokeWidth="1.5" />
        </svg>
        <div>
          <p className="tnum text-xl font-semibold text-surface">{formatWind(windSpeed, units)}</p>
          <p className="tnum text-xs text-surface-muted">from {compassPoint(windDirection)}</p>
          <p className="tnum text-xs text-surface-faint">gusts {formatWind(windGust, units)}</p>
        </div>
      </div>
    </ExpandableCard>
  );
}

function SunArc({ data, units }: { data: WeatherBundle; units: Units }) {
  const today = data.daily[0];
  if (!today) return null;

  const progress = sunProgress(today.sunrise, today.sunset, data.utcOffsetSeconds);
  const width = 150;
  const height = 64;
  const pad = 10;
  // Arc from (pad, height-6) to (width-pad, height-6), bulging up.
  const startX = pad;
  const endX = width - pad;
  const baseY = height - 6;
  const peakY = 10;
  const cx = (startX + endX) / 2;
  // Point on a quadratic bezier at t=progress
  const t = progress;
  const x = (1 - t) ** 2 * startX + 2 * (1 - t) * t * cx + t ** 2 * endX;
  const y = (1 - t) ** 2 * baseY + 2 * (1 - t) * t * peakY + t ** 2 * baseY;

  return (
    <Card icon={<Sun className="h-3.5 w-3.5" />} label="Sun path" className="sm:col-span-2">
      <div className="mt-1 flex items-end justify-between gap-2">
        <div className="tnum text-xs text-surface-muted">
          <span className="block text-sm font-semibold text-surface">
            {formatHour(today.sunrise, units)}
          </span>
          Sunrise
        </div>
        <svg
          viewBox={`0 0 ${width} ${height}`}
          className="h-16 min-w-0 flex-1"
          role="img"
          aria-label={`Sun is ${Math.round(progress * 100)}% through its arc`}
        >
          <path
            d={`M ${startX} ${baseY} Q ${cx} ${peakY} ${endX} ${baseY}`}
            fill="none"
            style={{ stroke: "var(--surface-border)" }}
            strokeWidth="2"
            strokeDasharray="4 5"
            strokeLinecap="round"
          />
          <path
            d={`M ${startX} ${baseY} Q ${cx} ${peakY} ${endX} ${baseY}`}
            fill="none"
            stroke="#45D1B3"
            strokeWidth="2.5"
            strokeLinecap="round"
            strokeDasharray="200"
            strokeDashoffset={200 - progress * 200}
            opacity={0.9}
          />
          <line x1={startX - 4} y1={baseY} x2={endX + 4} y2={baseY} style={{ stroke: "var(--surface-border)" }} strokeWidth="1.5" />
          <circle cx={x} cy={y} r="7" fill="#FFD9A0" opacity={0.25} />
          <circle cx={x} cy={y} r="4" fill="#FFD9A0" stroke="#fff" strokeOpacity={0.8} strokeWidth="1" />
        </svg>
        <div className="tnum text-right text-xs text-surface-muted">
          <span className="block text-sm font-semibold text-surface">
            {formatHour(today.sunset, units)}
          </span>
          Sunset
        </div>
      </div>
      <p className="tnum mt-1 text-[11px] text-surface-faint">
        Daylight {daylightLength(today.sunrise, today.sunset)}
      </p>
    </Card>
  );
}

export function MetricGrid({ data, units, city }: MetricGridProps) {
  const { current, hourly } = data;
  const next24 = hourly as HourlyPoint[];
  const maxPrecipChance = Math.max(...next24.map((hour) => hour.precipitationProbability), 0);
  const visibilityM = next24[0]?.visibility ?? 24_000;
  const dp = dewPoint(current.temperature, current.humidity);

  return (
    <div className="grid grid-cols-2 gap-3 sm:gap-4 lg:grid-cols-3">
      <WindCompass data={data} units={units} />
      <MarineCard city={city} units={units} />

      <ExpandableCard
        label="Humidity"
        group="humidity"
        bundle={data}
        units={units}
        icon={<Droplets className="h-3.5 w-3.5" />}
      >
        <p className="tnum mt-2 text-xl font-semibold text-surface">{Math.round(current.humidity)}%</p>
        <p className="tnum mt-1 text-xs text-surface-muted">Dew point {formatTemp(dp, units)}</p>
        <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-[var(--surface-subtle)]" aria-hidden="true">
          <div
            className="h-full rounded-full bg-gradient-to-r from-aurora-500 to-aurora-300 transition-all duration-500"
            style={{ width: `${Math.min(current.humidity, 100)}%` }}
          />
        </div>
      </ExpandableCard>

      {/* UV and Feels-like were removed here (v4.2 dedup): the Sun Safety
          card directly below this grid owns UV (curve + current value +
          burn times), and the hero + temperature dialog own feels-like. */}

      <ExpandableCard
        label="Visibility"
        group="visibility"
        bundle={data}
        units={units}
        icon={<Eye className="h-3.5 w-3.5" />}
      >
        <p className="tnum mt-2 text-xl font-semibold text-surface">
          {formatVisibility(visibilityM, units)}
        </p>
        <p className="mt-1 text-xs text-surface-muted">{visibilityLabel(visibilityM)}</p>
      </ExpandableCard>

      <ExpandableCard
        label="Pressure"
        group="pressure"
        bundle={data}
        units={units}
        icon={<Gauge className="h-3.5 w-3.5" />}
      >
        <p className="tnum mt-2 text-xl font-semibold text-surface">
          {formatPressure(current.pressure, units)}
        </p>
        <p className="mt-1 text-xs text-surface-muted">
          {current.pressure < 1000 ? 'Low' : current.pressure > 1025 ? 'High' : 'Normal'} · sea level
        </p>
      </ExpandableCard>

      <ExpandableCard
        label="Cloud cover"
        group="cloud"
        bundle={data}
        units={units}
        icon={<Cloud className="h-3.5 w-3.5" />}
      >
        <p className="tnum mt-2 text-xl font-semibold text-surface">{Math.round(current.cloudCover)}%</p>
        <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-[var(--surface-subtle)]" aria-hidden="true">
          <div
            className="h-full rounded-full bg-gradient-to-r from-aurora-300 to-aurora-500 transition-all duration-500"
            style={{ width: `${Math.min(current.cloudCover, 100)}%` }}
          />
        </div>
      </ExpandableCard>

      <ExpandableCard
        label="Precipitation"
        group="precip"
        bundle={data}
        units={units}
        icon={<Umbrella className="h-3.5 w-3.5" />}
      >
        <p className="tnum mt-2 text-xl font-semibold text-surface">
          {formatPrecip(current.precipitation, units)}
        </p>
        <p className="tnum mt-1 text-xs text-surface-muted">
          Up to {maxPrecipChance}% chance in 24h
        </p>
      </ExpandableCard>

      <SunArc data={data} units={units} />
    </div>
  );
}
